from django.contrib import admin
from .models import transformational_issue

class transformational_issue_admin(admin.ModelAdmin):
  list_display = ('issue_number', 'issue_name', 'env_3_relation', 'env_3_explanation', 'env_identify', 'production_e_relation', 'production_e_explanation', 'production_identify', 'chain_type', 'kgi_3_relation', 'kgi_3_kpi', 'kgi_3_upperkpi', 'kgi_identify', 'priority', 'level0_explanation', 'level1_explanation', 'level2_explanation', 'level3_explanation', 'level4_explanation', 'level5_explanation', 'asis_level', 'tobe_level')
  search_fields = ('issue_name',)

admin.site.register(transformational_issue, transformational_issue_admin)