from django.db import models

class transformational_issue(models.Model):
  issue_number = models.PositiveIntegerField()
  issue_name = models.CharField(max_length=200, default='')
  issue_image_icon = models.ImageField(upload_to='issues_image_icon/', blank=True, default='noImage.png')
  issue_image_5steps = models.ImageField(upload_to='issues_image_5steps/', blank=True, default='noImage.png')
  issue_image_system = models.ImageField(upload_to='issues_image_system/', blank=True, default='noImage.png')
  
  def save(self, *args, **kwargs):
    # 新しいファイルが設定されているか確認
    if self.pk is not None:  # 既存のオブジェクトの場合
      old_instance = transformational_issue.objects.get(pk=self.pk)
      # 新しいファイルが設定されていない場合（空の場合は無視）
      if not self.issue_image_5steps:
        self.issue_image_5steps = old_instance.issue_image_5steps
      if not self.issue_image_system:
        self.issue_image_system = old_instance.issue_image_system

    super().save(*args, **kwargs)  
  
  RELATION_CHOICES = [
    ('related', '関連'),
    ('unrelated', ''),
  ]

  STATUS_CHOICES = [
    ('not_set', '未設定'),
    ('candidate', '重点候補'),
    ('non_candidate', '非重点候補'),
  ]

  CHAIN_CHOICES = [
    ('null',''),
    ('engineering', 'エンジニアリングチェーン'),
    ('supply', 'サプライチェーン'),
    ('production', 'プロダクションチェーン'),
    ('service', 'サービスチェーン'),
  ]

  # 環境変化項目に関連
  env_3_relation = models.CharField(max_length=20, choices=RELATION_CHOICES, default='unrelated')
  env_3_explanation = models.TextField(default='ここには解説が入ります。')
  env_identify = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_set')

  # 生産システムに関連
  production_e_relation = models.CharField(max_length=20, choices=RELATION_CHOICES, default='unrelated')
  production_e_explanation = models.TextField(default='ここには解説が入ります。')
  production_identify = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_set')
  
  # KGI×4つのチェーンに関連
  chain_type = models.CharField(max_length=50, choices=CHAIN_CHOICES, default='null')
  kgi_3_relation = models.CharField(max_length=20, choices=RELATION_CHOICES, default='unrelated')
  kgi_3_kpi = models.TextField(default='ここにはKPIが入ります。')
  kgi_3_upperkpi = models.TextField(default='ここには上位KPIが入ります。')
  kgi_identify = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_set')
  
  # 重点候補から優先順位付け
  priority = models.PositiveIntegerField(null=True, blank=True, default=None)

  # As-IsとTo-Be
  level0_explanation = models.TextField(default='ここには解説が入ります。')
  level1_explanation = models.TextField(default='ここには解説が入ります。')
  level2_explanation = models.TextField(default='ここには解説が入ります。')
  level3_explanation = models.TextField(default='ここには解説が入ります。')
  level4_explanation = models.TextField(default='ここには解説が入ります。')
  level5_explanation = models.TextField(default='ここには解説が入ります。')
  asis_level = models.PositiveIntegerField(default=0)
  tobe_level = models.PositiveIntegerField(default=1)
  
  def __str__(self):
    return self.issue_name