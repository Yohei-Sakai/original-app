from django.conf import settings
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView, ListView
from django.db.models import Q
from .models import transformational_issue

class TopView(View):
  model = transformational_issue
  template_name = "top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class EnvTopView(View):
  model = transformational_issue
  template_name = "Env_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class IssueDetailView(View):  
  def get(self, request, issue_number):
    issue_detail = get_object_or_404(transformational_issue, issue_number=issue_number)
    return render(request, 'issue_detail.html', {'issue_detail': issue_detail})

class EnvIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Env_identify.html"
  context_object_name = "list_env"

  def get_queryset(self):
    queryset = super().get_queryset().filter(env_3_relation='related')
    return queryset
  
  def get(self, request, *args, **kwargs):
      if transformational_issue.objects.filter(env_identify='not_set').exists():
          messages.error(request, "重点か非重点を設定していない変革課題があります。他のページに進む前に重点か非重点を設定してください。")
      return super().get(request, *args, **kwargs)
  
class UpdateEnvIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_env3 = get_object_or_404(transformational_issue, pk=pk)
    
    action = request.POST.get('action')

    # アクションに基づいて状態を変更
    if action == 'set_candidate':
      issue_related_to_env3.env_identify = 'candidate'
    elif action == 'set_non_candidate':
      issue_related_to_env3.env_identify = 'non_candidate'
    elif action == 'reset':
      issue_related_to_env3.env_identify = 'not_set'

    issue_related_to_env3.save()  # データベースに変更を保存
    return redirect('Env_identify')  # リダイレクト

class ProductionTopView(View):
  model = transformational_issue
  template_name = "Production_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class ProductionIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Production_identify.html"
  context_object_name = "list_production"

  def get_queryset(self):
    queryset = super().get_queryset().filter(production_e_relation='related')
    return queryset

  def get(self, request, *args, **kwargs):
      if transformational_issue.objects.filter(production_identify='not_set').exists():
          messages.error(request, "重点か非重点を設定していない変革課題があります。他のページに進む前に重点か非重点を設定してください。")
      return super().get(request, *args, **kwargs)
  
class UpdateProductionIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_production_e = get_object_or_404(transformational_issue, pk=pk)

    action = request.POST.get('action')

    # アクションに基づいて状態を変更
    if action == 'set_candidate':
      issue_related_to_production_e.production_identify = 'candidate'
    elif action == 'set_non_candidate':
      issue_related_to_production_e.production_identify = 'non_candidate'
    elif action == 'reset':
      issue_related_to_production_e.production_identify = 'not_set'

    issue_related_to_production_e.save()  # データベースに変更を保存
    return redirect('Production_identify')  # リダイレクト

class KgiTopView(View):
  model = transformational_issue
  template_name = "Kgi_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name, {
      'MEDIA_URL': settings.MEDIA_URL,
    })

class KgiIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Kgi_identify.html"
  context_object_name = "list_kgi"

  def get_queryset(self):
    queryset = super().get_queryset().filter(kgi_3_relation='related')
    return queryset
  
  def get(self, request, *args, **kwargs):
      if transformational_issue.objects.filter(kgi_identify='not_set').exists():
          messages.error(request, "重点か非重点を設定していない変革課題があります。他のページに進む前に重点か非重点を設定してください。")
      return super().get(request, *args, **kwargs)  
  
class UpdateKgiIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_kgi_3 = get_object_or_404(transformational_issue, pk=pk)

    action = request.POST.get('action')

    # アクションに基づいて状態を変更
    if action == 'set_candidate':
      issue_related_to_kgi_3.kgi_identify = 'candidate'
    elif action == 'set_non_candidate':
      issue_related_to_kgi_3.kgi_identify = 'non_candidate'
    elif action == 'reset':
      issue_related_to_kgi_3.kgi_identify = 'not_set'

    issue_related_to_kgi_3.save()  # データベースに変更を保存
    return redirect('Kgi_identify')  # リダイレクト

class PriorityListView(ListView):
  model = transformational_issue
  template_name = "priority.html"
  context_object_name = "list_priority"

  def get_queryset(self):
    queryset = super().get_queryset().filter(
      Q(env_identify='candidate') |
      Q(production_identify='candidate') |
      Q(kgi_identify='candidate')
    )    
    return queryset

class UpdatePriorityView(View):
  def post(self, request, pk):
    issue_related_to_priority = get_object_or_404(transformational_issue, pk=pk)
            
    # ボタンの識別用にリクエストを確認
    if 'reset_priority' in request.POST:
      issue_related_to_priority.priority = None
    elif 'set_1st_priority' in request.POST:
      transformational_issue.objects.filter(priority=1).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 1
    elif 'set_2nd_priority' in request.POST:
      transformational_issue.objects.filter(priority=2).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 2
    elif 'set_3rd_priority' in request.POST:
      transformational_issue.objects.filter(priority=3).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 3

    issue_related_to_priority.save()  # データベースに変更を保存
    return redirect('priority')  # リダイレクト

class AsistobeListView(ListView):
  model = transformational_issue
  template_name = "asis_tobe.html"
  context_object_name = "list_asis_tobe"

  def get_queryset(self):
    queryset = super().get_queryset().filter(
      Q(priority=1) | Q(priority=2) | Q(priority=3)
    ).order_by('priority')
    return queryset

class IssueSystemView(View):  
  def get(self, request, issue_number):
    issue_system = get_object_or_404(transformational_issue, issue_number=issue_number)
    return render(request, 'issue_system.html', {'issue_system': issue_system})

class UpdateAsisLevelView(View):
  def post(self, request, pk, level):
    issue_related_asis_level = get_object_or_404(transformational_issue, pk=pk)
    if level < issue_related_asis_level.tobe_level:
      issue_related_asis_level.asis_level = level
      issue_related_asis_level.save()
    else:
      messages.error(request, "As-Is(現状)よりTo-Be(目指す姿)のレベルが上がるように設定してください")
    return redirect('asis_tobe')

class UpdateTobeLevelView(View):
  def post(self, request, pk, level):
    issue_related_tobe_level = get_object_or_404(transformational_issue, pk=pk)
    if level > issue_related_tobe_level.asis_level:
      issue_related_tobe_level.tobe_level = level  # To-beの場合のレベルを設定
      issue_related_tobe_level.save()
    else:
      messages.error(request, "As-Is(現状)よりTo-Be(目指す姿)のレベルが上がるように設定してください")      
    return redirect('asis_tobe')