from django.shortcuts import get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView, ListView
from django.db.models import Q
from .models import transformational_issue


class EnvIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Env_identify.html"
  context_object_name = "list_env"

  def get_queryset(self):
    queryset = super().get_queryset().filter(env_3_relation='related')
    return queryset
  
class UpdateEnvIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_env3 = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_env3.env_identify == 'non_candidate':
      issue_related_to_env3.env_identify = 'candidate'
    else:
      issue_related_to_env3.env_identify = 'non_candidate'  
    issue_related_to_env3.save()  # データベースに変更を保存
    return redirect('Env_identify')  # リダイレクト

class ProductionIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Production_identify.html"
  context_object_name = "list_production"

  def get_queryset(self):
    queryset = super().get_queryset().filter(production_e_relation='related')
    return queryset
  
class UpdateProductionIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_production_e = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_production_e.production_identify == 'non_candidate':
      issue_related_to_production_e.production_identify = 'candidate'
    else:
      issue_related_to_production_e.production_identify = 'non_candidate'  
    issue_related_to_production_e.save()  # データベースに変更を保存
    return redirect('Production_identify')  # リダイレクト

class KgiIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Kgi_identify.html"
  context_object_name = "list_kgi"

  def get_queryset(self):
    queryset = super().get_queryset().filter(kgi_3_relation='related')
    return queryset
  
class UpdateKgiIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_kgi_3 = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_kgi_3.kgi_identify == 'non_candidate':
      issue_related_to_kgi_3.kgi_identify = 'candidate'
    else:
      issue_related_to_kgi_3.kgi_identify = 'non_candidate'  
    issue_related_to_kgi_3.save()  # データベースに変更を保存
    return redirect('Kgi_identify')  # リダイレクト


class PriorityListView(ListView):
  model = transformational_issue
  template_name = "priority.html"
  context_object_name = "list_priority"

  def get_queryset(self):
    queryset = super().get_queryset().filter(
      Q(env_identify='candidate') |
      Q(production_identify='candidate') |
      Q(kgi_identify='candidate')
    )
    return queryset