from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView, ListView
from django.db.models import Q
from .models import transformational_issue

class EnvTopView(View):
  model = transformational_issue
  template_name = "Env_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class EnvIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Env_identify.html"
  context_object_name = "list_env"

  def get_queryset(self):
    queryset = super().get_queryset().filter(env_3_relation='related')
    return queryset
  
class UpdateEnvIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_env3 = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_env3.env_identify == 'non_candidate':
      issue_related_to_env3.env_identify = 'candidate'
    else:
      issue_related_to_env3.env_identify = 'non_candidate'  
    issue_related_to_env3.save()  # データベースに変更を保存
    return redirect('Env_identify')  # リダイレクト

class ProductionTopView(View):
  model = transformational_issue
  template_name = "Production_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class ProductionIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Production_identify.html"
  context_object_name = "list_production"

  def get_queryset(self):
    queryset = super().get_queryset().filter(production_e_relation='related')
    return queryset
  
class UpdateProductionIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_production_e = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_production_e.production_identify == 'non_candidate':
      issue_related_to_production_e.production_identify = 'candidate'
    else:
      issue_related_to_production_e.production_identify = 'non_candidate'  
    issue_related_to_production_e.save()  # データベースに変更を保存
    return redirect('Production_identify')  # リダイレクト

class KgiTopView(View):
  model = transformational_issue
  template_name = "Kgi_top.html"

  def get(self, request, *args, **kwargs):
    return render(request, self.template_name)

class KgiIdentifyListView(ListView):
  model = transformational_issue
  template_name = "Kgi_identify.html"
  context_object_name = "list_kgi"

  def get_queryset(self):
    queryset = super().get_queryset().filter(kgi_3_relation='related')
    return queryset
  
class UpdateKgiIdentifyView(View):
  def post(self, request, pk):
    issue_related_to_kgi_3 = get_object_or_404(transformational_issue, pk=pk)
    if issue_related_to_kgi_3.kgi_identify == 'non_candidate':
      issue_related_to_kgi_3.kgi_identify = 'candidate'
    else:
      issue_related_to_kgi_3.kgi_identify = 'non_candidate'  
    issue_related_to_kgi_3.save()  # データベースに変更を保存
    return redirect('Kgi_identify')  # リダイレクト

class PriorityListView(ListView):
  model = transformational_issue
  template_name = "priority.html"
  context_object_name = "list_priority"

  def get_queryset(self):
    queryset = super().get_queryset().filter(
      Q(env_identify='candidate') |
      Q(production_identify='candidate') |
      Q(kgi_identify='candidate')
    )    
    return queryset

class UpdatePriorityView(View):
  def post(self, request, pk):
    issue_related_to_priority = get_object_or_404(transformational_issue, pk=pk)
            
    # ボタンの識別用にリクエストを確認
    if 'reset_priority' in request.POST:
      issue_related_to_priority.priority = None
    elif 'set_1st_priority' in request.POST:
      transformational_issue.objects.filter(priority=1).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 1
    elif 'set_2nd_priority' in request.POST:
      transformational_issue.objects.filter(priority=2).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 2
    elif 'set_3rd_priority' in request.POST:
      transformational_issue.objects.filter(priority=3).exclude(pk=pk).update(priority=None)
      issue_related_to_priority.priority = 3

    issue_related_to_priority.save()  # データベースに変更を保存
    return redirect('priority')  # リダイレクト

class AsistobeListView(ListView):
  model = transformational_issue
  template_name = "asis_tobe.html"
  context_object_name = "list_asis_tobe"

  def get_queryset(self):
    queryset = super().get_queryset().filter(
      Q(priority=1) | Q(priority=2) | Q(priority=3)
    ).order_by('priority')
    return queryset

class UpdateAsisLevelView(View):
  def post(self, request, pk, level):
    issue_related_asis_level = get_object_or_404(transformational_issue, pk=pk)
    if level < issue_related_asis_level.tobe_level:
      issue_related_asis_level.asis_level = level
      issue_related_asis_level.save()
    else:
      messages.error(request, "As-Is(現状)よりTo-Be(目指す姿)のレベルが上がるように設定してください")
    return redirect('asis_tobe')

class UpdateTobeLevelView(View):
  def post(self, request, pk, level):
    issue_related_tobe_level = get_object_or_404(transformational_issue, pk=pk)
    if level > issue_related_tobe_level.asis_level:
      issue_related_tobe_level.tobe_level = level  # To-beの場合のレベルを設定
      issue_related_tobe_level.save()
    else:
      messages.error(request, "As-Is(現状)よりTo-Be(目指す姿)のレベルが上がるように設定してください")      
    return redirect('asis_tobe')