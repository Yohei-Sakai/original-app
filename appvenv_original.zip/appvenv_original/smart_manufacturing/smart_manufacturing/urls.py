"""
URL configuration for smart_manufacturing project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from sm_app import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('top/', views.TopView.as_view(), name="top"),
    path('issue_detail/<int:issue_number>/', views.IssueDetailView.as_view(), name="issue_detail"),
    path('Env_top/', views.EnvTopView.as_view(), name="Env_top"),
    path('Env_identify/', views.EnvIdentifyListView.as_view(), name="Env_identify"),
    path('Production_top/', views.ProductionTopView.as_view(), name="Production_top"),
    path('Production_identify/', views.ProductionIdentifyListView.as_view(), name="Production_identify"),
    path('Kgi_top/', views.KgiTopView.as_view(), name="Kgi_top"),
    path('Kgi_identify/', views.KgiIdentifyListView.as_view(), name="Kgi_identify"),
    path('priority/', views.PriorityListView.as_view(), name="priority"),
    path('update_env_identify/<int:pk>/', views.UpdateEnvIdentifyView.as_view(), name="update_env_identify"),
    path('update_production_identify/<int:pk>/', views.UpdateProductionIdentifyView.as_view(), name="update_production_identify"),
    path('update_kgi_identify/<int:pk>/', views.UpdateKgiIdentifyView.as_view(), name="update_kgi_identify"),
    path('update_priority/<int:pk>/', views.UpdatePriorityView.as_view(), name='update_priority'),
    path('asis_tobe/', views.AsistobeListView.as_view(), name='asis_tobe'),
    path('issue_system/<int:issue_number>/', views.IssueSystemView.as_view(), name="issue_system"),
    path('update_asis_level/<int:pk>/<int:level>/', views.UpdateAsisLevelView.as_view(), name="update_asis_level"),
    path('update_tobe_level/<int:pk>/<int:level>/', views.UpdateTobeLevelView.as_view(), name="update_tobe_level"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)